import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options 
from selenium.common.exceptions import NoSuchElementException

class Driver:
    
    def __init__(self):
        self.driver = self.create_driver()
      
    def create_driver(self):
        options = Options() 
        options.add_argument('--no-sandbox')
        options.add_argument('--headless')
        options.add_argument('--ignore-certificate-errors')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-extensions')
        options.add_argument('--disable-gpu')
        driver = webdriver.Chrome(options=options)
        return driver
      
    def recreate_driver(self):
        self.driver.quit()
        self.driver = self.create_driver()
        time.sleep(5)
        
    def refresh(self):
        self.driver.refresh()
        time.sleep(10)

    def login(self, url, username, password):
        self.driver.get(f'{url}#/login')
        time.sleep(5)
        self.driver.find_element(By.NAME, 'userNumber').send_keys(username)
        self.driver.find_element(By.CSS_SELECTOR, 'input[type="password"]').send_keys(password)
        self.driver.find_element(By.XPATH, '//button[text()="Log in"]').click()
        time.sleep(5)
        self.driver.get(f'{url}#/home/AllLotteryGames/WinGo?id=1')
        time.sleep(5)

    def bet(self, option, clicks):
        self.driver.find_element(By.CSS_SELECTOR, f'.Betting__C-foot-{option[0].lower()}').click()
        time.sleep(3)
        self.driver.find_element(By.XPATH, f'//div[@class="Betting__Popup-body-line-item" and contains(text(), "1")]').click()
        time.sleep(3)
        for _ in range(int(clicks / 1) - 1):
            self.driver.find_element(By.XPATH, f'//div[@class="Betting__Popup-btn bgcolor" and contains(text(), "+")]').click()
        self.driver.find_element(By.CLASS_NAME, 'Betting__Popup-foot-s').click()
        time.sleep(3)

    def wallet(self):
        balance_element = self.driver.find_element(By.CLASS_NAME, 'Wallet__C-balance-l1')
        balance_text = balance_element.find_element(By.TAG_NAME, 'div').text
        parse_balance = int(balance_text.replace('₹', '').replace(',', '').split('.')[0])
        return parse_balance