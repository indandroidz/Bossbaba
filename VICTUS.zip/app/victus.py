import time

from .config import URLs, LoginInfo, Config
from .helpers import Helpers as helper
from .driver import Driver

class Victus:
  
    def __init__(self):
       self.BET_AMOUNT     = Config.BET_AMOUNT
       self.TARGET_BALANCE = Config.TARGET_BALANCE
       self.EXPIRE_TIME    = Config.EXPIRE_TIME

    def run(self):
        while True:
            try:
                driver = Driver()
                driver.login(URLs.BASE_URL, LoginInfo.NUMBER, LoginInfo.PASSWORD)

                self.WALLET_BALANCE = driver.wallet()
                self.EXPIRE_TIME_SECONDS = time.time() + self.EXPIRE_TIME * 60

                while True:
                    driver.refresh()
                    self.CURRENT_BALANCE = driver.wallet()

                    if Config.BET_PLACED == None:
                        if helper.expire_time(self.EXPIRE_TIME_SECONDS):
                            self.EXPIRE_TIME_SECONDS = time.time() + self.EXPIRE_TIME * 60
                            Config.TARGET_REACHED = False
                            print(f"\033[96;7mExpired Time Reached, New Expire Time Set, Current Balance Is ₹{self.CURRENT_BALANCE}.\033[0m")
                            continue
                    
                        if helper.target_reached(self.CURRENT_BALANCE, self.WALLET_BALANCE, Config.TARGET_BALANCE):
                            if Config.TARGET_REACHED == False:
                                self.BET_AMOUNT = Config.BET_AMOUNT
                                self.WALLET_BALANCE = self.CURRENT_BALANCE
                                Config.TARGET_REACHED = True
                                print(f"\033[91;7mTarget Amount Reached, Current Balance Is ₹{self.CURRENT_BALANCE}\033[0m")
                            continue
                    
                    data = helper.api_data(URLs.API_URL, URLs.PAYLOAD)
                    
                    if len(data) >= 2:
                        last_period = int(data[0].get("issueNumber", 0))
                        next_period = int(last_period) + 1
                        last_number = int(data[0].get("number", 0))
                        last_size = 'Small' if last_number < 5 else 'Big'
                        next_size = helper.next_size(data)
                        
                        if Config.TARGET_REACHED == False:
                            if Config.BET_PLACED == None:
                                driver.bet(next_size, self.BET_AMOUNT)
                                Config.BET_PLACED = {"period": next_period, "size": next_size}
                                print(f"\033[94;7mBetting With Amount ₹{self.BET_AMOUNT}\033[0m")
                            elif Config.BET_PLACED != None:
                                if last_period == Config.BET_PLACED['period']:
                                    if last_size == Config.BET_PLACED['size']:
                                        self.BET_AMOUNT = Config.BET_AMOUNT
                                    else:
                                        self.BET_AMOUNT *= 2
                                    Config.BET_PLACED = None
            except KeyboardInterrupt:
                pass
            except Exception as e:
                #print(f"An error occurred: {e}")
                driver.recreate_driver()
                continue