class URLs:
    BASE_URL = "https://91club.club/"
    API_URL = "https://91clubapi.com/api/webapi/GetNoaverageEmerdList"
    PAYLOAD = {
        "pageSize": 10,
        "pageNo": 1,
        "typeId": 1,
        "language": 0,
        "random": "8858be15e380419a872d0bf2a8eb38e6",
        "signature": "F8B0F3F8BC08FDE271AE0CA9458E36BF",
        "timestamp": 1705928799
    }

class LoginInfo:
    NUMBER = "7903685937"
    PASSWORD = "Zeeshan786"
    
class Config:
    BET_AMOUNT = 3
    TARGET_BALANCE = 1
    EXPIRE_TIME = 5
    BET_PLACED = None
    TARGET_REACHED = False