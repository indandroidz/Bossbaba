import time
import random
import requests

class Helpers:
  
    @staticmethod
    def api_data(api_url, payload):
        try:
            response = requests.post(api_url, json=payload)
            response.raise_for_status()
            data = response.json().get('data', {}).get('list', [])
            return data
        except Exception as e:
            #print(f"Api Data Retrieval Error: {e}")
            return []
            
    @staticmethod
    def expire_time(expire_time):
        current_time = time.time()
        if current_time >= expire_time:
            return True
        return False

    @staticmethod
    def target_reached(current_balance, wallet_balance, target_balance):
        if current_balance is None:
            return False

        if current_balance >= wallet_balance + target_balance:
            return True
        
        return False
    
    @staticmethod
    def next_size(data):
        last_number = "Small" if int(data[0].get("number", 0)) < 5 else "Big"
        second_number = "Small" if int(data[1].get("number", 0)) < 5 else "Big"
        third_number = "Small" if int(data[2].get("number", 0)) < 5 else "Big"
        random_picker = "Small" if int(data[random.randint(0, 5)].get("number", 0)) < 5 else "Big"
        if last_number == second_number and second_number == third_number:
            print("Betting Logic 1")
            return "Small" if int(data[random.randint(0, 3)].get("number", 0)) < 5 else "Big"
        elif last_number != second_number and last_number == third_number:
            print("Betting Logic 2")
            return "Small" if int(data[random.randint(0, 3)].get("number", 0)) < 5 else "Big"
        else:
            print("Betting Random")
            return random_picker